import { useEffect, useRef } from 'react';

function App() {
  const initialized = useRef(false);

  useEffect(() => {
    if (initialized.current) return;
    initialized.current = true;

    // ===== DATA =====
    const products = [
      {
        id: 1, name: 'Ethiopian Yirgacheffe', origin: 'Ethiopia', category: 'Light Roast', roast: 'Light',
        price: 22.50, weight: '250g',
        description: 'A vibrant and complex coffee from the birthplace of arabica. Grown at high elevations in the Yirgacheffe region, this lot delivers an extraordinary cup with floral aromatics and a silky body that dances on the palate.',
        notes: ['Blueberry', 'Jasmine', 'Bergamot', 'Honey'],
        image: 'https://images.unsplash.com/photo-1559056199-641a0ac8b55e?w=400&h=400&fit=crop&crop=center', rating: 4.9
      },
      {
        id: 2, name: 'Colombian Supremo', origin: 'Colombia', category: 'Medium Roast', roast: 'Medium',
        price: 18.90, weight: '250g',
        description: 'Sourced from the lush highlands of Huila, this Supremo grade coffee embodies the perfect balance that Colombian beans are celebrated for. Smooth, sweet, and endlessly drinkable.',
        notes: ['Caramel', 'Red Apple', 'Milk Chocolate', 'Almond'],
        image: 'https://images.unsplash.com/photo-1587734195503-904fca47e0e9?w=400&h=400&fit=crop&crop=center', rating: 4.7
      },
      {
        id: 3, name: 'Sumatra Mandheling', origin: 'Indonesia', category: 'Dark Roast', roast: 'Dark',
        price: 21.00, weight: '250g',
        description: 'A bold and full-bodied coffee from the volcanic soils of northern Sumatra. Wet-hulled in the traditional Giling Basah method, it develops its signature earthy depth and syrupy texture.',
        notes: ['Dark Chocolate', 'Cedar', 'Tobacco', 'Brown Sugar'],
        image: 'https://images.unsplash.com/photo-1514432324607-a09d9b4aefda?w=400&h=400&fit=crop&crop=center', rating: 4.6
      },
      {
        id: 4, name: 'Guatemala Antigua', origin: 'Guatemala', category: 'Medium Roast', roast: 'Medium-Dark',
        price: 20.00, weight: '250g',
        description: 'Grown in the shadow of three volcanoes in the Antigua Valley, this coffee benefits from rich volcanic soil and a unique microclimate. The result is a remarkably smooth cup with layers of complexity.',
        notes: ['Cocoa', 'Spice', 'Orange Zest', 'Toffee'],
        image: 'https://images.unsplash.com/photo-1611854779393-1b2da9d400fe?w=400&h=400&fit=crop&crop=center', rating: 4.8
      },
      {
        id: 5, name: 'Kenya AA Nyeri', origin: 'Kenya', category: 'Light Roast', roast: 'Light-Medium',
        price: 24.00, weight: '250g',
        description: 'From the fertile red soils of Nyeri county, this AA graded lot showcases the best of Kenyan coffee. Bright, wine-like acidity meets intense fruit sweetness in a cup that is both elegant and powerful.',
        notes: ['Blackcurrant', 'Grapefruit', 'Tomato', 'Brown Sugar'],
        image: 'https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?w=400&h=400&fit=crop&crop=center', rating: 4.8
      },
      {
        id: 6, name: 'Brazil Santos', origin: 'Brazil', category: 'Dark Roast', roast: 'Medium',
        price: 16.50, weight: '250g',
        description: 'A crowd-pleasing classic from the rolling hills of Minas Gerais. This natural-process Santos delivers the comforting, nutty character that makes Brazilian coffee a beloved staple around the world.',
        notes: ['Hazelnut', 'Milk Chocolate', 'Dried Fruit', 'Cream'],
        image: 'https://images.unsplash.com/photo-1442512595331-e89e73853f31?w=400&h=400&fit=crop&crop=center', rating: 4.5
      }
    ];

    const categories = ['All', 'Light Roast', 'Medium Roast', 'Dark Roast'];

    // ===== STATE =====
    const state: any = {
      view: 'shop', selectedProduct: null, cart: [],
      searchQuery: '', activeCategory: 'All',
      searchOpen: false, cartOpen: false, detailQty: 1
    };

    // ===== ICONS =====
    const icons: any = {
      coffee: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 8h1a4 4 0 1 1 0 8h-1"/><path d="M3 8h14v9a4 4 0 0 1-4 4H7a4 4 0 0 1-4-4Z"/><line x1="6" y1="2" x2="6" y2="4"/><line x1="10" y1="2" x2="10" y2="4"/><line x1="14" y1="2" x2="14" y2="4"/></svg>',
      plus: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>',
      minus: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="5" y1="12" x2="19" y2="12"/></svg>',
      trash: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>',
      star: '<svg viewBox="0 0 24 24" fill="currentColor" stroke="currentColor" stroke-width="1"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>',
      arrowLeft: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="19" y1="12" x2="5" y2="12"/><polyline points="12 19 5 12 12 5"/></svg>',
      mapPin: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>',
      weight: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3a4 4 0 0 0-4 4h8a4 4 0 0 0-4-4z"/><path d="M2 21h20l-2-12H4L2 21z"/></svg>',
      check: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>',
      filter: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="22 3 2 3 10 12.46 10 19 14 21 14 12.46 22 3"/></svg>',
      chevronRight: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="9 18 15 12 9 6"/></svg>',
      x: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>',
      cart: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="9" cy="21" r="1"/><circle cx="20" cy="21" r="1"/><path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"/></svg>'
    };

    // ===== HELPERS =====
    function getCartCount() { return state.cart.reduce((s: number, i: any) => s + i.quantity, 0); }
    function getCartTotal() { return state.cart.reduce((s: number, i: any) => s + i.product.price * i.quantity, 0); }
    function getFilteredProducts() {
      return products.filter(p => {
        const q = state.searchQuery.toLowerCase();
        const matchesSearch = !q ||
          p.name.toLowerCase().includes(q) ||
          p.origin.toLowerCase().includes(q) ||
          p.notes.some((n: string) => n.toLowerCase().includes(q));
        const matchesCategory = state.activeCategory === 'All' || p.category === state.activeCategory;
        return matchesSearch && matchesCategory;
      });
    }

    function escapeHtml(str: string) {
      const div = document.createElement('div');
      div.textContent = str;
      return div.innerHTML;
    }

    // ===== ACTIONS =====
    function navigateTo(view: string) {
      state.view = view;
      state.selectedProduct = null;
      state.detailQty = 1;
      render();
    }

    function toggleSearch() {
      state.searchOpen = !state.searchOpen;
      const bar = document.getElementById('searchBar');
      if (state.searchOpen) {
        bar!.classList.remove('hidden');
        setTimeout(() => (document.getElementById('searchInput') as HTMLInputElement).focus(), 50);
      } else {
        bar!.classList.add('hidden');
      }
    }

    function handleSearch(val: string) {
      state.searchQuery = val;
      const clearBtn = document.getElementById('searchClear');
      if (val) clearBtn!.classList.remove('hidden');
      else clearBtn!.classList.add('hidden');
      if (state.view !== 'shop') state.view = 'shop';
      renderMain();
    }

    function clearSearch() {
      state.searchQuery = '';
      (document.getElementById('searchInput') as HTMLInputElement).value = '';
      document.getElementById('searchClear')!.classList.add('hidden');
      renderMain();
    }

    function setCategory(cat: string) {
      state.activeCategory = cat;
      renderMain();
    }

    function viewProduct(id: number) {
      state.selectedProduct = products.find(p => p.id === id);
      state.view = 'detail';
      state.detailQty = 1;
      render();
    }

    function addToCart(productId: number, qty?: number) {
      qty = qty || 1;
      const product = products.find(p => p.id === productId)!;
      const existing = state.cart.find((i: any) => i.product.id === productId);
      if (existing) existing.quantity += qty;
      else state.cart.push({ product, quantity: qty });
      updateCartBadge();
      if (state.cartOpen) renderCartSidebar();
    }

    function updateCartQty(productId: number, qty: number) {
      if (qty <= 0) state.cart = state.cart.filter((i: any) => i.product.id !== productId);
      else { const item = state.cart.find((i: any) => i.product.id === productId); if (item) item.quantity = qty; }
      updateCartBadge();
      renderCartSidebar();
    }

    function removeFromCart(productId: number) {
      state.cart = state.cart.filter((i: any) => i.product.id !== productId);
      updateCartBadge();
      renderCartSidebar();
    }

    function openCart() {
      state.cartOpen = true;
      document.getElementById('cartOverlay')!.classList.remove('hidden');
      document.getElementById('cartSidebar')!.classList.remove('hidden');
      renderCartSidebar();
    }

    function closeCart() {
      state.cartOpen = false;
      document.getElementById('cartOverlay')!.classList.add('hidden');
      document.getElementById('cartSidebar')!.classList.add('hidden');
    }

    function updateCartBadge() {
      const badge = document.getElementById('cartBadge')!;
      const count = getCartCount();
      if (count > 0) { badge.textContent = String(count); badge.classList.remove('hidden'); }
      else badge.classList.add('hidden');
    }

    function updateDetailQty(delta: number) {
      state.detailQty = Math.max(1, state.detailQty + delta);
      renderMain();
    }

    function goToCheckout() {
      closeCart();
      state.view = 'checkout';
      render();
    }

    function placeOrder() {
      state.view = 'confirmation';
      state.cart = [];
      updateCartBadge();
      render();
    }

    // ===== RENDER =====
    function render() { renderMain(); }

    function renderMain() {
      const main = document.getElementById('mainContent')!;
      switch (state.view) {
        case 'shop': main.innerHTML = renderShop(); break;
        case 'detail': main.innerHTML = renderDetail(); break;
        case 'checkout': main.innerHTML = renderCheckout(); break;
        case 'confirmation': main.innerHTML = renderConfirmation(); break;
      }
    }

    function renderShop() {
      const filtered = getFilteredProducts();
      let html = '<div class="animate-fadeIn">';
      html += '<div class="hero">';
      html += '<h1>Exceptional Coffee, <em>Curated</em></h1>';
      html += '<p>Hand-selected single-origin beans from the world\'s finest growing regions, roasted to perfection and delivered fresh to your door.</p>';
      html += '</div>';
      html += '<div class="filters">';
      html += '<span class="filter-icon">' + icons.filter + '</span>';
      categories.forEach(cat => {
        const active = state.activeCategory === cat ? ' active' : '';
        html += '<button class="filter-btn' + active + '" onclick="window.__setCategory(\'' + cat + '\')">' + cat + '</button>';
      });
      html += '</div>';
      if (state.searchQuery) {
        html += '<p class="results-count">' + filtered.length + ' result' + (filtered.length !== 1 ? 's' : '') + ' for &quot;' + escapeHtml(state.searchQuery) + '&quot;</p>';
      }
      if (filtered.length > 0) {
        html += '<div class="product-grid">';
        filtered.forEach((p, i) => {
          html += '<div class="product-card" style="animation-delay:' + (i * 80) + 'ms">';
          html += '<div class="card-image-wrap">';
          html += '<img class="card-image" src="' + p.image + '" alt="' + escapeHtml(p.name) + '" loading="lazy">';
          html += '<span class="card-badge">' + escapeHtml(p.roast) + ' Roast</span>';
          html += '<button class="card-quick-add" onclick="event.stopPropagation();window.__addToCart(' + p.id + ')" title="Add to cart">' + icons.plus + '</button>';
          html += '</div>';
          html += '<div class="card-body">';
          html += '<div class="card-header">';
          html += '<button class="card-title" onclick="window.__viewProduct(' + p.id + ')">' + escapeHtml(p.name) + '</button>';
          html += '<div class="card-rating">' + icons.star + '<span>' + p.rating + '</span></div>';
          html += '</div>';
          html += '<div class="card-origin">' + icons.mapPin + '<span>' + escapeHtml(p.origin) + '</span></div>';
          html += '<div class="card-notes">';
          p.notes.slice(0, 3).forEach((n: string) => { html += '<span class="card-note">' + escapeHtml(n) + '</span>'; });
          html += '</div>';
          html += '<div class="card-footer">';
          html += '<div><span class="card-price">$' + p.price.toFixed(2) + '</span><span class="card-price-unit">/ ' + p.weight + '</span></div>';
          html += '<button class="card-add-btn" onclick="window.__addToCart(' + p.id + ')">Add to Cart</button>';
          html += '</div></div></div>';
        });
        html += '</div>';
      } else {
        html += '<div class="empty-state">';
        html += icons.coffee;
        html += '<p>No coffees found matching your search.</p>';
        html += '<p class="empty-sub">Try adjusting your filters or search terms.</p>';
        html += '</div>';
      }
      html += '</div>';
      return html;
    }

    function renderDetail() {
      const p = state.selectedProduct;
      if (!p) return '';
      let html = '<div class="detail-wrap">';
      html += '<button class="detail-back" onclick="window.__navigateTo(\'shop\')">';
      html += icons.arrowLeft;
      html += '<span>Back to Shop</span></button>';
      html += '<div class="detail-grid">';
      html += '<div class="detail-image"><img src="' + p.image + '" alt="' + escapeHtml(p.name) + '"></div>';
      html += '<div>';
      html += '<span class="detail-badge">' + escapeHtml(p.roast) + ' Roast</span>';
      html += '<h1 class="detail-title">' + escapeHtml(p.name) + '</h1>';
      html += '<div class="detail-meta">';
      html += '<div class="detail-meta-item">' + icons.mapPin + '<span>' + escapeHtml(p.origin) + '</span></div>';
      html += '<span class="detail-meta-divider">\u2022</span>';
      html += '<div class="detail-meta-item">' + icons.weight + '<span>' + p.weight + '</span></div>';
      html += '<span class="detail-meta-divider">\u2022</span>';
      html += '<div class="detail-meta-item">' + icons.star + '<span>' + p.rating + '</span></div>';
      html += '</div>';
      html += '<p class="detail-description">' + escapeHtml(p.description) + '</p>';
      html += '<p class="detail-notes-title">Tasting Notes</p>';
      html += '<div class="detail-notes">';
      p.notes.forEach((n: string) => { html += '<span class="detail-note">' + escapeHtml(n) + '</span>'; });
      html += '</div>';
      html += '<div class="detail-purchase">';
      html += '<div><span class="detail-price">$' + p.price.toFixed(2) + '</span>';
      html += '<span class="detail-price-unit">/ ' + p.weight + '</span></div>';
      html += '<div class="detail-actions">';
      html += '<div class="qty-control">';
      html += '<button class="qty-btn" onclick="window.__updateDetailQty(-1)">' + icons.minus + '</button>';
      html += '<span class="qty-value">' + state.detailQty + '</span>';
      html += '<button class="qty-btn" onclick="window.__updateDetailQty(1)">' + icons.plus + '</button>';
      html += '</div>';
      html += '<button class="detail-add-btn" onclick="window.__addToCart(' + p.id + ',' + state.detailQty + ')">';
      html += icons.cart;
      html += 'Add to Cart \u2014 $' + (p.price * state.detailQty).toFixed(2);
      html += '</button>';
      html += '</div></div>';
      html += '</div></div></div>';
      return html;
    }

    function renderCartSidebar() {
      const sidebar = document.getElementById('cartSidebar')!;
      const count = getCartCount();
      const total = getCartTotal();
      let html = '<div class="cart-header">';
      html += '<div class="cart-title">' + icons.cart + 'Your Cart';
      if (count > 0) html += '<span class="cart-count-label">(' + count + ' items)</span>';
      html += '</div>';
      html += '<button class="cart-close" onclick="window.__closeCart()">' + icons.x + '</button>';
      html += '</div>';
      html += '<div class="cart-items">';
      if (state.cart.length === 0) {
        html += '<div class="cart-empty">';
        html += icons.cart;
        html += '<p>Your cart is empty</p>';
        html += '<p class="cart-empty-sub">Add some delicious coffee to get started!</p>';
        html += '</div>';
      } else {
        state.cart.forEach((item: any) => {
          html += '<div class="cart-item">';
          html += '<img class="cart-item-img" src="' + item.product.image + '" alt="' + escapeHtml(item.product.name) + '">';
          html += '<div class="cart-item-info">';
          html += '<div class="cart-item-name">' + escapeHtml(item.product.name) + '</div>';
          html += '<div class="cart-item-weight">' + item.product.weight + '</div>';
          html += '<div class="cart-item-price">$' + (item.product.price * item.quantity).toFixed(2) + '</div>';
          html += '<div class="cart-item-controls">';
          html += '<div class="cart-qty">';
          html += '<button class="cart-qty-btn" onclick="window.__updateCartQty(' + item.product.id + ',' + (item.quantity - 1) + ')">' + icons.minus + '</button>';
          html += '<span class="cart-qty-val">' + item.quantity + '</span>';
          html += '<button class="cart-qty-btn" onclick="window.__updateCartQty(' + item.product.id + ',' + (item.quantity + 1) + ')">' + icons.plus + '</button>';
          html += '</div>';
          html += '<button class="cart-remove" onclick="window.__removeFromCart(' + item.product.id + ')">' + icons.trash + '</button>';
          html += '</div></div></div>';
        });
      }
      html += '</div>';
      if (state.cart.length > 0) {
        html += '<div class="cart-footer">';
        html += '<div class="cart-subtotal">';
        html += '<span class="cart-subtotal-label">Subtotal</span>';
        html += '<span class="cart-subtotal-value">$' + total.toFixed(2) + '</span>';
        html += '</div>';
        html += '<p class="cart-shipping-note">Shipping calculated at checkout</p>';
        html += '<button class="cart-checkout-btn" onclick="window.__goToCheckout()">';
        html += 'Proceed to Checkout' + icons.chevronRight;
        html += '</button>';
        html += '</div>';
      }
      sidebar.innerHTML = html;
    }

    function renderCheckout() {
      const total = getCartTotal();
      const shipping = 5.99;
      const grandTotal = total + shipping;
      let itemsHtml = '';
      state.cart.forEach((item: any) => {
        itemsHtml += '<div class="order-item">';
        itemsHtml += '<img class="order-item-img" src="' + item.product.image + '" alt="' + escapeHtml(item.product.name) + '">';
        itemsHtml += '<div class="order-item-info">';
        itemsHtml += '<div class="order-item-name">' + escapeHtml(item.product.name) + '</div>';
        itemsHtml += '<div class="order-item-qty">Qty: ' + item.quantity + '</div>';
        itemsHtml += '</div>';
        itemsHtml += '<div class="order-item-price">$' + (item.product.price * item.quantity).toFixed(2) + '</div>';
        itemsHtml += '</div>';
      });
      let html = '<div class="checkout-wrap">';
      html += '<button class="detail-back" onclick="window.__navigateTo(\'shop\')">';
      html += icons.arrowLeft + '<span>Back to Shop</span></button>';
      html += '<h1 class="checkout-title">Checkout</h1>';
      html += '<div class="checkout-grid">';
      html += '<form onsubmit="event.preventDefault();window.__placeOrder();">';
      html += '<div class="checkout-section">';
      html += '<h2 class="checkout-section-title">Contact Information</h2>';
      html += '<div class="form-group"><label class="form-label">Email</label>';
      html += '<input class="form-input" type="email" required placeholder="your@email.com"></div>';
      html += '<div class="form-group"><label class="form-label">Full Name</label>';
      html += '<input class="form-input" type="text" required placeholder="John Doe"></div>';
      html += '</div>';
      html += '<div class="checkout-section">';
      html += '<h2 class="checkout-section-title">Shipping Address</h2>';
      html += '<div class="form-group"><label class="form-label">Address</label>';
      html += '<input class="form-input" type="text" required placeholder="123 Coffee Lane"></div>';
      html += '<div class="form-row">';
      html += '<div class="form-group"><label class="form-label">City</label>';
      html += '<input class="form-input" type="text" required placeholder="Portland"></div>';
      html += '<div class="form-group"><label class="form-label">ZIP Code</label>';
      html += '<input class="form-input" type="text" required placeholder="97201"></div>';
      html += '</div></div>';
      html += '<div class="checkout-section">';
      html += '<h2 class="checkout-section-title">Payment</h2>';
      html += '<div class="form-group"><label class="form-label">Card Number</label>';
      html += '<input class="form-input" type="text" required placeholder="4242 4242 4242 4242"></div>';
      html += '<div class="form-row">';
      html += '<div class="form-group"><label class="form-label">Expiry</label>';
      html += '<input class="form-input" type="text" required placeholder="MM/YY"></div>';
      html += '<div class="form-group"><label class="form-label">CVV</label>';
      html += '<input class="form-input" type="text" required placeholder="123"></div>';
      html += '</div></div>';
      html += '<button type="submit" class="checkout-submit">Place Order \u2014 $' + grandTotal.toFixed(2) + '</button>';
      html += '</form>';
      html += '<div><div class="order-summary">';
      html += '<h2 class="order-summary-title">Order Summary</h2>';
      html += itemsHtml;
      html += '<div class="order-totals">';
      html += '<div class="order-total-row"><span class="label">Subtotal</span><span class="value">$' + total.toFixed(2) + '</span></div>';
      html += '<div class="order-total-row"><span class="label">Shipping</span><span class="value">$' + shipping.toFixed(2) + '</span></div>';
      html += '<div class="order-total-final"><span class="label">Total</span><span class="value">$' + grandTotal.toFixed(2) + '</span></div>';
      html += '</div></div></div>';
      html += '</div></div>';
      return html;
    }

    function renderConfirmation() {
      const orderNum = 'EB-' + Math.random().toString(36).substring(2, 8).toUpperCase();
      let html = '<div class="confirmation">';
      html += '<div class="confirmation-icon">' + icons.check + '</div>';
      html += '<h1>Order Confirmed!</h1>';
      html += '<p class="conf-msg">Thank you for your purchase.</p>';
      html += '<p class="conf-sub">Your freshly roasted coffee is on its way. We\'ll send you a tracking number once your order ships.</p>';
      html += '<div class="confirmation-order">';
      html += '<p class="label">Order Number</p>';
      html += '<p class="order-num">' + orderNum + '</p>';
      html += '</div>';
      html += '<button class="confirmation-btn" onclick="window.__navigateTo(\'shop\')">Continue Shopping</button>';
      html += '</div>';
      return html;
    }

    // Expose functions globally for inline onclick handlers
    (window as any).__navigateTo = navigateTo;
    (window as any).__toggleSearch = toggleSearch;
    (window as any).__handleSearch = handleSearch;
    (window as any).__clearSearch = clearSearch;
    (window as any).__setCategory = setCategory;
    (window as any).__viewProduct = viewProduct;
    (window as any).__addToCart = addToCart;
    (window as any).__updateCartQty = updateCartQty;
    (window as any).__removeFromCart = removeFromCart;
    (window as any).__openCart = openCart;
    (window as any).__closeCart = closeCart;
    (window as any).__updateDetailQty = updateDetailQty;
    (window as any).__goToCheckout = goToCheckout;
    (window as any).__placeOrder = placeOrder;

    // Initial render
    render();
  }, []);

  return (
    <div style={{ minHeight: '100vh', backgroundColor: '#fefdf8' }}>
      <header className="header">
        <div className="header-inner">
          <button className="logo" onClick={() => (window as any).__navigateTo?.('shop')}>
            <svg className="logo-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M17 8h1a4 4 0 1 1 0 8h-1"/><path d="M3 8h14v9a4 4 0 0 1-4 4H7a4 4 0 0 1-4-4Z"/><line x1="6" y1="2" x2="6" y2="4"/><line x1="10" y1="2" x2="10" y2="4"/><line x1="14" y1="2" x2="14" y2="4"/>
            </svg>
            <span className="logo-text">Ember &amp; Bloom</span>
          </button>
          <div className="nav-actions">
            <button className="nav-btn" onClick={() => (window as any).__toggleSearch?.()}>
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>
              </svg>
              <span className="nav-btn-text">Search</span>
            </button>
            <button className="nav-btn" onClick={() => (window as any).__openCart?.()}>
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <circle cx="9" cy="21" r="1"/><circle cx="20" cy="21" r="1"/><path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"/>
              </svg>
              <span className="nav-btn-text">Cart</span>
              <span className="cart-badge hidden" id="cartBadge">0</span>
            </button>
          </div>
        </div>
        <div className="header-inner">
          <div className="search-bar hidden" id="searchBar" style={{ width: '100%' }}>
            <div className="search-input-wrap">
              <svg className="search-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>
              </svg>
              <input type="text" className="search-input" id="searchInput" placeholder="Search by name, origin, or tasting notes..." onInput={(e) => (window as any).__handleSearch?.((e.target as HTMLInputElement).value)} />
              <button className="search-clear hidden" id="searchClear" onClick={() => (window as any).__clearSearch?.()}>
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>
                </svg>
              </button>
            </div>
          </div>
        </div>
      </header>
      <main className="main" id="mainContent"></main>
      <div className="cart-overlay hidden" id="cartOverlay" onClick={() => (window as any).__closeCart?.()}></div>
      <div className="cart-sidebar hidden" id="cartSidebar"></div>
    </div>
  );
}

export default App;
